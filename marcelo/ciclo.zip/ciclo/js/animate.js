function flip(){
$( ".login" ).toggle();
$( ".description" ).toggle();
};

function prof(){
$( ".profesional" ).toggle();
};

function subcat(){
$(".categories").toggle();
$(".subcategories").toggle();

};